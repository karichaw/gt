# ConstructConnect - Construction Project Marketplace

A marketplace platform connecting project owners with specialized contractors using a detailed industry classification system.

## Project Structure

- `client/`: Frontend React application
- `server/`: Backend Express API
- `shared/`: Shared TypeScript types and schemas

## Setup Instructions

1. Install dependencies:
   ```
   npm install
   ```

2. Start the development server:
   ```
   npm run dev
   ```

3. Open http://localhost:5000 in your browser

## Authentication

For demo purposes, use:
- Project Owner: username "projectowner", password "password123"
- Contractor: username "contractor", password "password123"

## Features

- Construction project classification system with detailed categorization:
  - Building Projects (Residential, Commercial, Institutional)
  - Infrastructure Projects (Roads/Highways, Bridges, Sewage Systems)
  - Industrial Projects (Plant Civil Works, Industrial Buildings, Mechanical Structures)
  - Specialized Projects (Renovations, Interior Finishing, Landscaping)
  
- Project creation interface with comprehensive details
- Search and filtering system for projects
- Contractor profiles with specializations and portfolio
- Project proposal submissions
- Dashboard views for both project owners and contractors

## Technology Stack

- **Frontend**: React, TailwindCSS, shadcn/ui components
- **Backend**: Express.js
- **Storage**: In-memory storage (can be connected to PostgreSQL)
- **API**: RESTful endpoints for all CRUD operations
- **State Management**: React Context API and TanStack Query