import { pgTable, text, serial, integer, boolean, jsonb, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  userType: text("user_type", { enum: ["project_owner", "contractor"] }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Project model
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  ownerId: integer("owner_id").notNull(),
  projectType: text("project_type", { 
    enum: ["building", "infrastructure", "industrial", "specialized"] 
  }).notNull(),
  subCategory: text("sub_category").notNull(),
  description: text("description").notNull(),
  startDate: text("start_date").notNull(), // Format: YYYY-MM-DD
  durationValue: integer("duration_value").notNull(),
  durationType: text("duration_type", { 
    enum: ["days", "weeks", "months"] 
  }).notNull(),
  area: text("area"),
  city: text("city").notNull(),
  state: text("state").notNull(),
  teamSizeMin: integer("team_size_min"),
  teamSizeMax: integer("team_size_max"),
  experienceRequired: text("experience_required"),
  skills: text("skills").array(),
  budgetMin: numeric("budget_min"),
  budgetMax: numeric("budget_max"),
  budgetType: text("budget_type", { 
    enum: ["per_day", "per_week", "per_month", "total"] 
  }),
  status: text("status", { 
    enum: ["draft", "open", "awarded", "ongoing", "completed", "cancelled"] 
  }).notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
});

// Contractor profile model
export const contractorProfiles = pgTable("contractor_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  companyName: text("company_name"),
  experience: text("experience").notNull(),
  teamSize: text("team_size").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  willingToTravel: text("willing_to_travel").array(),
  languagesSpoken: text("languages_spoken").array(),
  specializations: jsonb("specializations").notNull().default({}),
  projectTypes: text("project_types").array(),
  maxProjectValue: text("max_project_value"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertContractorProfileSchema = createInsertSchema(contractorProfiles).omit({
  id: true,
  createdAt: true,
});

// Portfolio projects for contractors
export const portfolioProjects = pgTable("portfolio_projects", {
  id: serial("id").primaryKey(),
  contractorId: integer("contractor_id").notNull(),
  title: text("title").notNull(),
  projectType: text("project_type").notNull(),
  role: text("role").notNull(),
  description: text("description").notNull(),
  projectDate: text("project_date").notNull(),
  duration: text("duration").notNull(),
  location: text("location"),
  images: text("images").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPortfolioProjectSchema = createInsertSchema(portfolioProjects).omit({
  id: true,
  createdAt: true,
});

// Project proposals from contractors
export const proposals = pgTable("proposals", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  contractorId: integer("contractor_id").notNull(),
  message: text("message").notNull(),
  budget: numeric("budget"),
  timeline: text("timeline"),
  status: text("status", { 
    enum: ["pending", "accepted", "rejected"] 
  }).notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProposalSchema = createInsertSchema(proposals).omit({
  id: true,
  createdAt: true,
});

// Define types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type ContractorProfile = typeof contractorProfiles.$inferSelect;
export type InsertContractorProfile = z.infer<typeof insertContractorProfileSchema>;

export type PortfolioProject = typeof portfolioProjects.$inferSelect;
export type InsertPortfolioProject = z.infer<typeof insertPortfolioProjectSchema>;

export type Proposal = typeof proposals.$inferSelect;
export type InsertProposal = z.infer<typeof insertProposalSchema>;
