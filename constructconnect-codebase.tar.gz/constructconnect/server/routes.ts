import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertProjectSchema, insertContractorProfileSchema, insertPortfolioProjectSchema, insertProposalSchema } from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Helper function to handle Zod validation errors
  const validateRequest = <T extends z.ZodType>(schema: T, data: unknown): z.infer<T> => {
    try {
      return schema.parse(data);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        throw { status: 400, message: validationError.message };
      }
      throw error;
    }
  };

  // AUTH ROUTES
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = validateRequest(insertUserSchema, req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json({ id: user.id, username: user.username, userType: user.userType });
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      res.status(200).json({ id: user.id, username: user.username, userType: user.userType });
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  // PROJECT ROUTES
  app.get("/api/projects", async (req: Request, res: Response) => {
    try {
      // Parse query parameters for filtering
      const {
        projectType,
        subCategory,
        city,
        state,
        status,
        skills
      } = req.query;
      
      const filters: Record<string, any> = {};
      
      if (projectType) filters.projectType = projectType;
      if (subCategory) filters.subCategory = subCategory;
      if (city) filters.city = city;
      if (state) filters.state = state;
      if (status) filters.status = status;
      if (skills) filters.skills = (skills as string).split(',');
      
      const projects = await storage.getProjects(filters);
      res.status(200).json(projects);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.get("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.status(200).json(project);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.post("/api/projects", async (req: Request, res: Response) => {
    try {
      const projectData = validateRequest(insertProjectSchema, req.body);
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.put("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const updatedProject = await storage.updateProject(id, req.body);
      res.status(200).json(updatedProject);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.delete("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      await storage.deleteProject(id);
      res.status(204).send();
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  // CONTRACTOR PROFILE ROUTES
  app.get("/api/contractor-profiles/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const profile = await storage.getContractorProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Contractor profile not found" });
      }
      
      res.status(200).json(profile);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.post("/api/contractor-profiles", async (req: Request, res: Response) => {
    try {
      const profileData = validateRequest(insertContractorProfileSchema, req.body);
      const profile = await storage.createContractorProfile(profileData);
      res.status(201).json(profile);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.put("/api/contractor-profiles/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const profile = await storage.getContractorProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Contractor profile not found" });
      }
      
      const updatedProfile = await storage.updateContractorProfile(userId, req.body);
      res.status(200).json(updatedProfile);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  // PORTFOLIO PROJECT ROUTES
  app.get("/api/portfolio/:contractorId", async (req: Request, res: Response) => {
    try {
      const contractorId = parseInt(req.params.contractorId);
      if (isNaN(contractorId)) {
        return res.status(400).json({ message: "Invalid contractor ID" });
      }
      
      const projects = await storage.getPortfolioProjects(contractorId);
      res.status(200).json(projects);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.post("/api/portfolio", async (req: Request, res: Response) => {
    try {
      const projectData = validateRequest(insertPortfolioProjectSchema, req.body);
      const project = await storage.createPortfolioProject(projectData);
      res.status(201).json(project);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.put("/api/portfolio/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid portfolio project ID" });
      }
      
      const updatedProject = await storage.updatePortfolioProject(id, req.body);
      if (!updatedProject) {
        return res.status(404).json({ message: "Portfolio project not found" });
      }
      
      res.status(200).json(updatedProject);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.delete("/api/portfolio/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid portfolio project ID" });
      }
      
      const success = await storage.deletePortfolioProject(id);
      if (!success) {
        return res.status(404).json({ message: "Portfolio project not found" });
      }
      
      res.status(204).send();
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  // PROPOSAL ROUTES
  app.get("/api/proposals/project/:projectId", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      if (isNaN(projectId)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const proposals = await storage.getProposals(projectId);
      res.status(200).json(proposals);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.get("/api/proposals/contractor/:contractorId", async (req: Request, res: Response) => {
    try {
      const contractorId = parseInt(req.params.contractorId);
      if (isNaN(contractorId)) {
        return res.status(400).json({ message: "Invalid contractor ID" });
      }
      
      const proposals = await storage.getProposalsByContractor(contractorId);
      res.status(200).json(proposals);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.post("/api/proposals", async (req: Request, res: Response) => {
    try {
      const proposalData = validateRequest(insertProposalSchema, req.body);
      const proposal = await storage.createProposal(proposalData);
      res.status(201).json(proposal);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  app.put("/api/proposals/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid proposal ID" });
      }
      
      const updatedProposal = await storage.updateProposal(id, req.body);
      if (!updatedProposal) {
        return res.status(404).json({ message: "Proposal not found" });
      }
      
      res.status(200).json(updatedProposal);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
