import { 
  users, type User, type InsertUser,
  projects, type Project, type InsertProject,
  contractorProfiles, type ContractorProfile, type InsertContractorProfile,
  portfolioProjects, type PortfolioProject, type InsertPortfolioProject,
  proposals, type Proposal, type InsertProposal
} from "@shared/schema";

// Storage interface for all entities
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getProjects(filters?: Partial<Project>): Promise<Project[]>;
  getProjectsByOwner(ownerId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  
  // Contractor profile operations
  getContractorProfile(userId: number): Promise<ContractorProfile | undefined>;
  createContractorProfile(profile: InsertContractorProfile): Promise<ContractorProfile>;
  updateContractorProfile(userId: number, profile: Partial<ContractorProfile>): Promise<ContractorProfile | undefined>;
  
  // Portfolio project operations
  getPortfolioProjects(contractorId: number): Promise<PortfolioProject[]>;
  createPortfolioProject(project: InsertPortfolioProject): Promise<PortfolioProject>;
  updatePortfolioProject(id: number, project: Partial<PortfolioProject>): Promise<PortfolioProject | undefined>;
  deletePortfolioProject(id: number): Promise<boolean>;
  
  // Proposal operations
  getProposals(projectId: number): Promise<Proposal[]>;
  getProposalsByContractor(contractorId: number): Promise<Proposal[]>;
  createProposal(proposal: InsertProposal): Promise<Proposal>;
  updateProposal(id: number, proposal: Partial<Proposal>): Promise<Proposal | undefined>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private contractorProfiles: Map<number, ContractorProfile>;
  private portfolioProjects: Map<number, PortfolioProject>;
  private proposals: Map<number, Proposal>;
  
  private userIdCounter: number;
  private projectIdCounter: number;
  private contractorProfileIdCounter: number;
  private portfolioProjectIdCounter: number;
  private proposalIdCounter: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.contractorProfiles = new Map();
    this.portfolioProjects = new Map();
    this.proposals = new Map();
    
    this.userIdCounter = 1;
    this.projectIdCounter = 1;
    this.contractorProfileIdCounter = 1;
    this.portfolioProjectIdCounter = 1;
    this.proposalIdCounter = 1;
    
    // Add some initial data for development
    this.initDemoData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  // Project operations
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjects(filters?: Partial<Project>): Promise<Project[]> {
    let projects = Array.from(this.projects.values());
    
    if (filters) {
      projects = projects.filter(project => {
        return Object.entries(filters).every(([key, value]) => {
          if (key === 'skills' && Array.isArray(value) && Array.isArray(project.skills)) {
            return (value as string[]).some(skill => project.skills.includes(skill));
          }
          return project[key as keyof Project] === value;
        });
      });
    }
    
    // Sort by created date, newest first
    return projects.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getProjectsByOwner(ownerId: number): Promise<Project[]> {
    return Array.from(this.projects.values())
      .filter(project => project.ownerId === ownerId)
      .sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.projectIdCounter++;
    const project: Project = { ...insertProject, id, createdAt: new Date() };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, projectUpdate: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { ...project, ...projectUpdate };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  // Contractor profile operations
  async getContractorProfile(userId: number): Promise<ContractorProfile | undefined> {
    return Array.from(this.contractorProfiles.values()).find(
      profile => profile.userId === userId
    );
  }

  async createContractorProfile(insertProfile: InsertContractorProfile): Promise<ContractorProfile> {
    const id = this.contractorProfileIdCounter++;
    const profile: ContractorProfile = { ...insertProfile, id, createdAt: new Date() };
    this.contractorProfiles.set(id, profile);
    return profile;
  }

  async updateContractorProfile(userId: number, profileUpdate: Partial<ContractorProfile>): Promise<ContractorProfile | undefined> {
    const profile = Array.from(this.contractorProfiles.values()).find(
      p => p.userId === userId
    );
    
    if (!profile) return undefined;
    
    const updatedProfile = { ...profile, ...profileUpdate };
    this.contractorProfiles.set(profile.id, updatedProfile);
    return updatedProfile;
  }

  // Portfolio project operations
  async getPortfolioProjects(contractorId: number): Promise<PortfolioProject[]> {
    return Array.from(this.portfolioProjects.values())
      .filter(project => project.contractorId === contractorId)
      .sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  async createPortfolioProject(insertProject: InsertPortfolioProject): Promise<PortfolioProject> {
    const id = this.portfolioProjectIdCounter++;
    const project: PortfolioProject = { ...insertProject, id, createdAt: new Date() };
    this.portfolioProjects.set(id, project);
    return project;
  }

  async updatePortfolioProject(id: number, projectUpdate: Partial<PortfolioProject>): Promise<PortfolioProject | undefined> {
    const project = this.portfolioProjects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { ...project, ...projectUpdate };
    this.portfolioProjects.set(id, updatedProject);
    return updatedProject;
  }

  async deletePortfolioProject(id: number): Promise<boolean> {
    return this.portfolioProjects.delete(id);
  }

  // Proposal operations
  async getProposals(projectId: number): Promise<Proposal[]> {
    return Array.from(this.proposals.values())
      .filter(proposal => proposal.projectId === projectId)
      .sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  async getProposalsByContractor(contractorId: number): Promise<Proposal[]> {
    return Array.from(this.proposals.values())
      .filter(proposal => proposal.contractorId === contractorId)
      .sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  async createProposal(insertProposal: InsertProposal): Promise<Proposal> {
    const id = this.proposalIdCounter++;
    const proposal: Proposal = { ...insertProposal, id, createdAt: new Date() };
    this.proposals.set(id, proposal);
    return proposal;
  }

  async updateProposal(id: number, proposalUpdate: Partial<Proposal>): Promise<Proposal | undefined> {
    const proposal = this.proposals.get(id);
    if (!proposal) return undefined;
    
    const updatedProposal = { ...proposal, ...proposalUpdate };
    this.proposals.set(id, updatedProposal);
    return updatedProposal;
  }

  // Initialize demo data
  private initDemoData() {
    // Create demo users
    const owner = this.createUser({
      username: "projectowner",
      password: "password123",
      fullName: "Rajesh Kumar",
      email: "rajesh@example.com",
      phone: "9876543210",
      userType: "project_owner"
    });

    const contractor = this.createUser({
      username: "contractor",
      password: "password123",
      fullName: "Sunil Singh",
      email: "sunil@example.com",
      phone: "9876543211",
      userType: "contractor"
    });

    // Create demo projects
    this.createProject({
      title: "Bridge Refurbishment Project",
      ownerId: 1,
      projectType: "infrastructure",
      subCategory: "bridges",
      description: "Refurbishment of existing 45m bridge including structural repairs, expansion joint replacement, and surface restoration in Whitefield area.",
      startDate: "2023-08-15",
      durationValue: 4,
      durationType: "months",
      area: "Whitefield",
      city: "Bangalore",
      state: "Karnataka",
      teamSizeMin: 8,
      teamSizeMax: 15,
      experienceRequired: "3+ years",
      skills: ["Bridge Construction", "Structural Work", "Concrete Repair", "Civil Engineering", "Surface Finishing"],
      budgetMin: 2500000,
      budgetMax: 3000000,
      budgetType: "total",
      status: "open"
    });

    this.createProject({
      title: "Road Repair and Resurfacing",
      ownerId: 1,
      projectType: "infrastructure",
      subCategory: "roads",
      description: "Repair and resurfacing of 2km road segment including pothole filling, edge repair, and asphalt overlay in Koramangala area.",
      startDate: "2023-07-10",
      durationValue: 1,
      durationType: "months",
      area: "Koramangala",
      city: "Bangalore",
      state: "Karnataka",
      teamSizeMin: 5,
      teamSizeMax: 8,
      experienceRequired: "1+ years",
      skills: ["Road Construction", "Asphalt Work", "Drainage", "Surface Preparation"],
      budgetMin: 500000,
      budgetMax: 700000,
      budgetType: "total",
      status: "open"
    });

    // Create contractor profile
    this.createContractorProfile({
      userId: 2,
      companyName: "RK Infrastructure Solutions",
      experience: "3-5 years",
      teamSize: "6-10 workers",
      city: "Bangalore",
      state: "Karnataka",
      willingToTravel: ["Karnataka", "Tamil Nadu"],
      languagesSpoken: ["Hindi", "Kannada", "English"],
      specializations: {
        "Bridge Works": ["Bridge Construction", "Structural Steel", "Concrete Work"],
        "Road Works": ["Road Construction", "Asphalt Work", "Drainage"]
      },
      projectTypes: ["Bridges/Culverts", "Roads/Highways", "Drains/Sewage Systems"],
      maxProjectValue: "₹1 crore - ₹5 crores"
    });
  }
}

export const storage = new MemStorage();
