import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/card';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useProject } from '../contexts/ProjectContext';
import { useAuth } from '../contexts/AuthContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { insertProjectSchema } from '@shared/schema';

const ProjectCreation = () => {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const { getProjectTypes, getSubCategories, createProject } = useProject();
  
  const [projectType, setProjectType] = useState('');
  const [subCategory, setSubCategory] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  
  // Project form validation schema
  const projectSchema = z.object({
    title: z.string().min(5, "Title must be at least 5 characters"),
    projectType: z.string().min(1, "Project type is required"),
    subCategory: z.string().min(1, "Sub-category is required"),
    description: z.string().min(20, "Description must be at least 20 characters"),
    startDate: z.string().min(1, "Start date is required"),
    durationValue: z.number().positive("Duration must be positive"),
    durationType: z.string().min(1, "Duration type is required"),
    area: z.string().optional(),
    city: z.string().min(1, "City is required"),
    state: z.string().min(1, "State is required"),
    teamSizeMin: z.number().nonnegative().optional(),
    teamSizeMax: z.number().positive().optional(),
    experienceRequired: z.string().optional(),
    budgetMin: z.number().nonnegative().optional(),
    budgetMax: z.number().positive().optional(),
    budgetType: z.string().optional(),
  });

  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<z.infer<typeof projectSchema>>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      title: '',
      projectType: '',
      subCategory: '',
      description: '',
      startDate: new Date().toISOString().split('T')[0],
      durationValue: 1,
      durationType: 'months',
      area: '',
      city: '',
      state: '',
      teamSizeMin: 5,
      teamSizeMax: 10,
      experienceRequired: 'Any Experience',
      budgetMin: undefined,
      budgetMax: undefined,
      budgetType: 'total',
    }
  });

  // Watch form values
  const formValues = watch();
  
  // Handle project type selection
  const handleProjectTypeSelect = (type: string) => {
    setProjectType(type);
    setValue('projectType', type);
    setSubCategory('');
    setValue('subCategory', '');
  };
  
  // Handle sub-category selection
  const handleSubCategorySelect = (category: string) => {
    setSubCategory(category);
    setValue('subCategory', category);
  };
  
  // Add skill
  const handleAddSkill = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && newSkill.trim()) {
      e.preventDefault();
      if (!skills.includes(newSkill.trim())) {
        setSkills([...skills, newSkill.trim()]);
      }
      setNewSkill('');
    }
  };
  
  // Remove skill
  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter(skill => skill !== skillToRemove));
  };
  
  // Form submission
  const onSubmit = async (data: z.infer<typeof projectSchema>) => {
    try {
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please log in to post a project",
          variant: "destructive"
        });
        setLocation('/dashboard');
        return;
      }
      
      // Prepare project data
      const projectData = {
        ...data,
        ownerId: user.id,
        skills: skills.length ? skills : ['General Construction'],
        status: 'open',
      };
      
      // Create project
      await createProject(projectData);
      
      toast({
        title: "Project created!",
        description: "Your project has been posted successfully",
      });
      
      setLocation('/dashboard');
    } catch (error) {
      console.error('Failed to create project:', error);
      toast({
        title: "Failed to create project",
        description: "Please try again later",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader className="bg-primary-600 text-white p-4 flex flex-row items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" className="text-white mr-2" onClick={() => setLocation('/dashboard')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-lg font-bold">Post New Project</h2>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="bg-white text-primary-600 hover:bg-primary-50 hover:text-primary-700"
          onClick={() => toast({
            title: "Draft saved",
            description: "Your project draft has been saved"
          })}
        >
          Save Draft
        </Button>
      </CardHeader>
      
      <CardContent className="p-6">
        <form id="projectForm" onSubmit={handleSubmit(onSubmit)}>
          {/* Project Basic Info */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Project Basic Info</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Project Title</Label>
                <Input 
                  id="title"
                  placeholder="e.g. 3-floor Residential Building Construction"
                  {...register('title')}
                />
                {errors.title && (
                  <p className="text-sm text-red-500 mt-1">{errors.title.message}</p>
                )}
              </div>
            </div>
          </div>
          
          {/* Project Classification */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Project Classification</h3>
            <div className="space-y-4">
              <div>
                <Label>Project Type</Label>
                <div className="grid grid-cols-2 gap-3 mt-1">
                  {getProjectTypes().map(type => (
                    <div 
                      key={type.id}
                      className={`border rounded-lg p-3 cursor-pointer transition hover:border-primary-400 hover:bg-primary-50 ${
                        projectType === type.id ? 'bg-primary-50 border-primary-500' : ''
                      }`}
                      onClick={() => handleProjectTypeSelect(type.id)}
                    >
                      <p className="font-medium text-sm">{type.name}</p>
                    </div>
                  ))}
                </div>
                {errors.projectType && (
                  <p className="text-sm text-red-500 mt-1">{errors.projectType.message}</p>
                )}
              </div>
              
              {projectType && (
                <div>
                  <Label>Project Sub-Category</Label>
                  <div className="grid grid-cols-1 gap-2 mt-1">
                    {getSubCategories(projectType).map(category => (
                      <div 
                        key={category.id}
                        className={`border rounded-lg p-3 cursor-pointer transition hover:border-primary-400 hover:bg-primary-50 ${
                          subCategory === category.id ? 'bg-primary-50 border-primary-500' : ''
                        }`}
                        onClick={() => handleSubCategorySelect(category.id)}
                      >
                        <p className="font-medium text-sm">{category.name}</p>
                      </div>
                    ))}
                  </div>
                  {errors.subCategory && (
                    <p className="text-sm text-red-500 mt-1">{errors.subCategory.message}</p>
                  )}
                </div>
              )}
            </div>
          </div>
          
          {/* Project Details */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Project Details</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="description">Project Description</Label>
                <Textarea 
                  id="description"
                  className="h-24"
                  placeholder="Describe your project requirements, scope of work, etc."
                  {...register('description')}
                />
                {errors.description && (
                  <p className="text-sm text-red-500 mt-1">{errors.description.message}</p>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input 
                    id="startDate"
                    type="date"
                    {...register('startDate')}
                  />
                  {errors.startDate && (
                    <p className="text-sm text-red-500 mt-1">{errors.startDate.message}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="duration">Duration</Label>
                  <div className="flex">
                    <Input 
                      id="durationValue"
                      type="number"
                      className="rounded-r-none"
                      {...register('durationValue', { valueAsNumber: true })}
                    />
                    <Select 
                      defaultValue="months"
                      onValueChange={value => setValue('durationType', value)}
                    >
                      <SelectTrigger className="w-[120px] rounded-l-none">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="days">Days</SelectItem>
                        <SelectItem value="weeks">Weeks</SelectItem>
                        <SelectItem value="months">Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {(errors.durationValue || errors.durationType) && (
                    <p className="text-sm text-red-500 mt-1">
                      {errors.durationValue?.message || errors.durationType?.message}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Location */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Project Location</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="area">Area/Locality</Label>
                <Input 
                  id="area"
                  placeholder="e.g. Whitefield"
                  {...register('area')}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="city">City</Label>
                  <Select 
                    defaultValue=""
                    onValueChange={value => setValue('city', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select City" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Bangalore">Bangalore</SelectItem>
                      <SelectItem value="Mumbai">Mumbai</SelectItem>
                      <SelectItem value="Delhi">Delhi</SelectItem>
                      <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                      <SelectItem value="Chennai">Chennai</SelectItem>
                      <SelectItem value="Kolkata">Kolkata</SelectItem>
                      <SelectItem value="Pune">Pune</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.city && (
                    <p className="text-sm text-red-500 mt-1">{errors.city.message}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="state">State</Label>
                  <Select 
                    defaultValue=""
                    onValueChange={value => setValue('state', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select State" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Karnataka">Karnataka</SelectItem>
                      <SelectItem value="Maharashtra">Maharashtra</SelectItem>
                      <SelectItem value="Delhi">Delhi</SelectItem>
                      <SelectItem value="Telangana">Telangana</SelectItem>
                      <SelectItem value="Tamil Nadu">Tamil Nadu</SelectItem>
                      <SelectItem value="West Bengal">West Bengal</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.state && (
                    <p className="text-sm text-red-500 mt-1">{errors.state.message}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Labor Requirements */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Labor Requirements</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Team Size</Label>
                  <div className="flex">
                    <Input 
                      type="number"
                      className="w-20 rounded-r-none"
                      {...register('teamSizeMin', { valueAsNumber: true })}
                    />
                    <div className="flex items-center justify-center px-3 border-t border-b border-gray-300 bg-gray-50">
                      to
                    </div>
                    <Input 
                      type="number"
                      className="w-20 rounded-l-none"
                      {...register('teamSizeMax', { valueAsNumber: true })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="experienceRequired">Experience Required</Label>
                  <Select 
                    defaultValue="Any Experience"
                    onValueChange={value => setValue('experienceRequired', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Any Experience">Any Experience</SelectItem>
                      <SelectItem value="1+ years">1+ years</SelectItem>
                      <SelectItem value="3+ years">3+ years</SelectItem>
                      <SelectItem value="5+ years">5+ years</SelectItem>
                      <SelectItem value="10+ years">10+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label>Skills Required</Label>
                <div className="border rounded-md p-2 flex flex-wrap gap-1 bg-white min-h-[40px]">
                  {skills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="bg-primary-100 text-primary-800 border-none">
                      {skill}
                      <button 
                        type="button"
                        className="ml-1 text-primary-600 hover:text-primary-800"
                        onClick={() => handleRemoveSkill(skill)}
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                  <Input 
                    type="text"
                    className="flex-grow p-1 border-0 text-sm focus:outline-none focus:ring-0"
                    placeholder="Add more skills..."
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyDown={handleAddSkill}
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">Press Enter to add a skill</p>
              </div>
            </div>
          </div>
          
          {/* Budget Information */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Budget Information</h3>
            <div className="space-y-4">
              <div>
                <Label>Budget Range (Optional)</Label>
                <div className="flex items-center flex-wrap md:flex-nowrap gap-2 md:gap-0">
                  <div className="flex items-center">
                    <span className="p-2 border border-r-0 rounded-l-md bg-gray-50">₹</span>
                    <Input 
                      type="number"
                      className="w-32 rounded-none"
                      placeholder="20,000"
                      {...register('budgetMin', { valueAsNumber: true })}
                    />
                  </div>
                  <span className="p-2 border-t border-b border-gray-300 bg-gray-50 hidden md:block">to</span>
                  <div className="flex items-center">
                    <span className="p-2 border border-r-0 rounded-l-md md:rounded-none bg-gray-50 md:border-l-0">₹</span>
                    <Input 
                      type="number"
                      className="w-32 rounded-none"
                      placeholder="50,000"
                      {...register('budgetMax', { valueAsNumber: true })}
                    />
                  </div>
                  <Select 
                    defaultValue="total"
                    onValueChange={value => setValue('budgetType', value)}
                  >
                    <SelectTrigger className="rounded-l-none w-[150px]">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="per_day">Per Day</SelectItem>
                      <SelectItem value="per_week">Per Week</SelectItem>
                      <SelectItem value="per_month">Per Month</SelectItem>
                      <SelectItem value="total">Total</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </form>
      </CardContent>
      
      <CardFooter className="flex justify-end gap-3 pt-6 border-t">
        <Button 
          variant="outline" 
          onClick={() => toast({
            title: "Draft saved",
            description: "Your project draft has been saved"
          })}
        >
          Save Draft
        </Button>
        <Button 
          type="submit"
          form="projectForm"
        >
          Post Project
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProjectCreation;
