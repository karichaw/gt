import React from 'react';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { Building2, Search, UserCircle, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '../contexts/AuthContext';

const Home = () => {
  const [_, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();

  return (
    <div className="py-4">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-700 to-primary-900 rounded-xl p-8 mb-10 text-white">
        <div className="max-w-3xl">
          <h1 className="text-4xl font-bold mb-4">
            Connect Construction Projects with Specialized Contractors
          </h1>
          <p className="text-xl mb-8 text-primary-100">
            India's first marketplace matching construction projects with qualified contractors using a detailed industry classification system.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button 
              size="lg" 
              className="bg-white text-primary-700 hover:bg-primary-50"
              onClick={() => setLocation('/create-project')}
            >
              Post a Project
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-white border-white hover:bg-primary-800"
              onClick={() => setLocation('/project-search')}
            >
              Find Projects
            </Button>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6 text-center">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="bg-primary-100 text-primary-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Building2 className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Post Your Project</h3>
              <p className="text-gray-600">
                Create a detailed project listing using our structured classification system to accurately describe your construction needs.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="bg-primary-100 text-primary-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Match with Contractors</h3>
              <p className="text-gray-600">
                Our intelligent matching system connects your project with qualified contractors who have the right skills and experience.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="bg-primary-100 text-primary-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Complete Your Project</h3>
              <p className="text-gray-600">
                Review proposals, select the right contractor, and manage your project through completion all on one platform.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gray-50 rounded-xl p-8 mb-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to get started?</h2>
        <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
          Join thousands of project owners and contractors already using ConstructConnect to find their perfect match.
        </p>
        {!isAuthenticated ? (
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              onClick={() => setLocation('/create-project')}
            >
              Post a Project
            </Button>
            <Button 
              size="lg"
              variant="outline"
              onClick={() => setLocation('/contractor-profile')}
            >
              Create Contractor Profile
            </Button>
          </div>
        ) : (
          <Button 
            size="lg" 
            onClick={() => setLocation('/dashboard')}
          >
            Go to Dashboard
          </Button>
        )}
      </div>

      {/* Project Categories */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Project Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-lg border hover:shadow-md transition cursor-pointer"
               onClick={() => setLocation('/project-search?type=building')}>
            <h3 className="font-semibold mb-2">Building Projects</h3>
            <p className="text-sm text-gray-600 mb-2">Residential, Commercial, Institutional</p>
            <div className="flex justify-end">
              <span className="text-primary-600">Browse &rarr;</span>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg border hover:shadow-md transition cursor-pointer"
               onClick={() => setLocation('/project-search?type=infrastructure')}>
            <h3 className="font-semibold mb-2">Infrastructure Projects</h3>
            <p className="text-sm text-gray-600 mb-2">Roads, Bridges, Drainage Systems</p>
            <div className="flex justify-end">
              <span className="text-primary-600">Browse &rarr;</span>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg border hover:shadow-md transition cursor-pointer"
               onClick={() => setLocation('/project-search?type=industrial')}>
            <h3 className="font-semibold mb-2">Industrial Projects</h3>
            <p className="text-sm text-gray-600 mb-2">Plant Civil Works, Industrial Buildings</p>
            <div className="flex justify-end">
              <span className="text-primary-600">Browse &rarr;</span>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg border hover:shadow-md transition cursor-pointer"
               onClick={() => setLocation('/project-search?type=specialized')}>
            <h3 className="font-semibold mb-2">Specialized Projects</h3>
            <p className="text-sm text-gray-600 mb-2">Renovation, Interior Finishing, Landscaping</p>
            <div className="flex justify-end">
              <span className="text-primary-600">Browse &rarr;</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
