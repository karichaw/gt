import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Building2, FileCheck, CheckCheck, CalendarPlus, User, Search } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Sidebar from '@/components/Sidebar';
import ProjectCard from '@/components/ProjectCard';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

// Mock login form for demonstration
const LoginForm = ({ onLogin }: { onLogin: (username: string, password: string) => Promise<void> }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      await onLogin(username, password);
    } catch (error) {
      toast({
        title: "Login failed",
        description: "Invalid username or password",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card className="max-w-md mx-auto p-6">
      <CardHeader className="text-center">
        <h2 className="text-2xl font-bold">Login to ConstructConnect</h2>
        <p className="text-gray-500">Access your dashboard</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Username</label>
            <Input 
              type="text" 
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <Input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? 'Logging in...' : 'Login'}
          </Button>
          
          <div className="text-center text-sm text-gray-500 mt-4">
            <p>For demo purposes, use:</p>
            <p className="font-medium">username: projectowner, password: password123</p>
            <p className="font-medium">username: contractor, password: password123</p>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

const Dashboard = () => {
  const [_, setLocation] = useLocation();
  const { isAuthenticated, user, login } = useAuth();
  const [activeTab, setActiveTab] = useState('active');
  
  // Fetch projects by owner or relevant to contractor
  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ['/api/projects', user?.id],
    enabled: !!isAuthenticated && !!user?.id,
    queryFn: async () => {
      if (user?.userType === 'project_owner') {
        // Fetch projects owned by this user
        const res = await fetch(`/api/projects?ownerId=${user.id}`);
        if (!res.ok) throw new Error('Failed to fetch projects');
        return await res.json();
      } else {
        // For contractors, fetch all open projects (would normally be recommended matches)
        const res = await fetch('/api/projects?status=open');
        if (!res.ok) throw new Error('Failed to fetch projects');
        return await res.json();
      }
    }
  });
  
  // Fetch proposals if contractor
  const { data: proposals, isLoading: isLoadingProposals } = useQuery({
    queryKey: ['/api/proposals/contractor', user?.id],
    enabled: !!isAuthenticated && !!user?.id && user?.userType === 'contractor',
    queryFn: async () => {
      const res = await fetch(`/api/proposals/contractor/${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch proposals');
      return await res.json();
    }
  });
  
  // Filter projects based on active tab
  const filteredProjects = React.useMemo(() => {
    if (!projects) return [];
    
    switch (activeTab) {
      case 'active':
        return projects.filter(p => p.status === 'open' || p.status === 'ongoing');
      case 'completed':
        return projects.filter(p => p.status === 'completed');
      case 'draft':
        return projects.filter(p => p.status === 'draft');
      default:
        return projects;
    }
  }, [projects, activeTab]);

  // If not authenticated, show login form
  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto py-10">
        <LoginForm onLogin={login} />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
      {/* Main Dashboard Content */}
      <div className="md:col-span-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          {user?.userType === 'project_owner' ? (
            <Button onClick={() => setLocation('/create-project')}>
              <CalendarPlus className="h-4 w-4 mr-2" />
              Post New Project
            </Button>
          ) : (
            <Button onClick={() => setLocation('/project-search')}>
              <Search className="h-4 w-4 mr-2" />
              Find Projects
            </Button>
          )}
        </div>
        
        <Card className="mb-6">
          <CardHeader className="bg-gray-50 pb-3">
            <div className="flex justify-between items-center">
              <h2 className="font-medium text-lg">
                {user?.userType === 'project_owner' ? 'Your Projects' : 'Your Work'}
              </h2>
              <div className="flex items-center text-sm text-gray-500">
                <User className="h-4 w-4 mr-1" />
                {user?.userType === 'project_owner' ? 'Project Owner' : 'Contractor'}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab}>
              <div className="border-b">
                <TabsList className="bg-transparent border-b-0">
                  <TabsTrigger value="active" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary-600">
                    Active
                  </TabsTrigger>
                  <TabsTrigger value="completed" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary-600">
                    Completed
                  </TabsTrigger>
                  {user?.userType === 'project_owner' && (
                    <TabsTrigger value="draft" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary-600">
                      Drafts
                    </TabsTrigger>
                  )}
                </TabsList>
              </div>
              
              <TabsContent value="active" className="p-4">
                {isLoadingProjects ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Loading projects...</p>
                  </div>
                ) : filteredProjects.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No active projects found.</p>
                    {user?.userType === 'project_owner' ? (
                      <Button variant="link" onClick={() => setLocation('/create-project')}>
                        Post a new project
                      </Button>
                    ) : (
                      <Button variant="link" onClick={() => setLocation('/project-search')}>
                        Find projects to work on
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredProjects.map(project => (
                      <ProjectCard key={project.id} project={project} />
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="completed" className="p-4">
                {isLoadingProjects ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Loading projects...</p>
                  </div>
                ) : filteredProjects.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No completed projects found.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredProjects.map(project => (
                      <ProjectCard key={project.id} project={project} />
                    ))}
                  </div>
                )}
              </TabsContent>
              
              {user?.userType === 'project_owner' && (
                <TabsContent value="draft" className="p-4">
                  {isLoadingProjects ? (
                    <div className="text-center py-8">
                      <p className="text-gray-500">Loading drafts...</p>
                    </div>
                  ) : filteredProjects.length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-gray-500">No draft projects found.</p>
                      <Button variant="link" onClick={() => setLocation('/create-project')}>
                        Start a new project
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredProjects.map(project => (
                        <ProjectCard key={project.id} project={project} />
                      ))}
                    </div>
                  )}
                </TabsContent>
              )}
            </Tabs>
          </CardContent>
        </Card>
        
        {/* Proposals Section (for Contractors) */}
        {user?.userType === 'contractor' && (
          <Card>
            <CardHeader className="bg-gray-50 pb-3">
              <h2 className="font-medium text-lg">Your Proposals</h2>
            </CardHeader>
            <CardContent className="p-4">
              {isLoadingProposals ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">Loading proposals...</p>
                </div>
              ) : !proposals || proposals.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">No proposals submitted yet.</p>
                  <Button variant="link" onClick={() => setLocation('/project-search')}>
                    Find projects to bid on
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {proposals.map((proposal: any) => (
                    <Card key={proposal.id} className="border p-4">
                      <div className="flex justify-between mb-2">
                        <div>
                          <h3 className="font-medium">Proposal for Project #{proposal.projectId}</h3>
                          <p className="text-sm text-gray-500">Submitted on {new Date(proposal.createdAt).toLocaleDateString()}</p>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          proposal.status === 'accepted' 
                            ? 'bg-green-100 text-green-800' 
                            : proposal.status === 'rejected'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        } capitalize`}>
                          {proposal.status}
                        </span>
                      </div>
                      <p className="text-sm mb-2">{proposal.message}</p>
                      {proposal.budget && (
                        <p className="text-sm font-medium">Budget: ₹{proposal.budget}</p>
                      )}
                      {proposal.timeline && (
                        <p className="text-sm">Timeline: {proposal.timeline}</p>
                      )}
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* Sidebar */}
      <div className="md:col-span-4">
        <Sidebar />
      </div>
    </div>
  );
};

export default Dashboard;
