import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '../contexts/AuthContext';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useQuery, useMutation } from '@tanstack/react-query';

const ContractorProfile = () => {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('basic');
  
  // Form state
  const [companyName, setCompanyName] = useState('');
  const [experience, setExperience] = useState('3-5 years');
  const [teamSize, setTeamSize] = useState('6-10 workers');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [willingToTravel, setWillingToTravel] = useState<string[]>([]);
  const [newLocation, setNewLocation] = useState('');
  const [languagesSpoken, setLanguagesSpoken] = useState<string[]>([]);
  const [newLanguage, setNewLanguage] = useState('');
  
  // Specialization state
  const [selectedSpecializations, setSelectedSpecializations] = useState<Record<string, string[]>>({});
  const [selectedProjectTypes, setSelectedProjectTypes] = useState<string[]>([]);
  const [maxProjectValue, setMaxProjectValue] = useState('');
  
  // Portfolio state
  const [portfolioProjects, setPortfolioProjects] = useState<any[]>([]);
  const [newProject, setNewProject] = useState({
    title: '',
    projectType: '',
    role: '',
    description: '',
    projectDate: '',
    duration: '',
    location: '',
    images: [] as string[]
  });
  
  // Industry specializations based on the project classifications
  const specializations = [
    { 
      category: 'Building Works', 
      skills: ['Masonry', 'Plastering', 'Tiling', 'Concrete Work', 'Formwork', 'Carpentry', 'Painting']
    },
    { 
      category: 'Infrastructure', 
      skills: ['Road Construction', 'Bridge Works', 'Culvert Construction', 'Drainage Systems', 'Earthwork']
    },
    { 
      category: 'Industrial', 
      skills: ['Plant Civil Works', 'Structural Steel', 'Tankage', 'Piping', 'Electrical', 'Mechanical Installation']
    },
    { 
      category: 'Specialized', 
      skills: ['Waterproofing', 'Interior Finishing', 'Landscaping', 'Restoration', 'Demolition']
    }
  ];
  
  // Project types
  const projectTypes = [
    { id: 'residential', name: 'Residential Buildings' },
    { id: 'commercial', name: 'Commercial Buildings' },
    { id: 'roads', name: 'Roads/Highways/Drains' },
    { id: 'bridges', name: 'Bridges' },
    { id: 'plant', name: 'Plant-based Jobs' },
    { id: 'industrial', name: 'Industrial Buildings' }
  ];
  
  // Fetch contractor profile data
  const { data: profileData, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['/api/contractor-profiles', user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      try {
        const res = await fetch(`/api/contractor-profiles/${user?.id}`);
        if (res.status === 404) {
          return null;
        }
        if (!res.ok) {
          throw new Error('Failed to fetch profile');
        }
        return await res.json();
      } catch (error) {
        console.error('Error fetching profile:', error);
        return null;
      }
    }
  });
  
  // Fetch portfolio projects
  const { data: portfolioData } = useQuery({
    queryKey: ['/api/portfolio', user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      try {
        const res = await fetch(`/api/portfolio/${user?.id}`);
        if (!res.ok) {
          throw new Error('Failed to fetch portfolio');
        }
        return await res.json();
      } catch (error) {
        console.error('Error fetching portfolio:', error);
        return [];
      }
    }
  });
  
  // Create/update profile mutation
  const profileMutation = useMutation({
    mutationFn: async (profileData: any) => {
      if (profileData.id) {
        // Update existing profile
        return apiRequest('PUT', `/api/contractor-profiles/${user?.id}`, profileData);
      } else {
        // Create new profile
        return apiRequest('POST', '/api/contractor-profiles', profileData);
      }
    },
    onSuccess: () => {
      toast({
        title: "Profile saved",
        description: "Your profile has been updated successfully"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/contractor-profiles', user?.id] });
    },
    onError: (error) => {
      toast({
        title: "Error saving profile",
        description: "Please try again later",
        variant: "destructive"
      });
      console.error('Error saving profile:', error);
    }
  });
  
  // Create portfolio project mutation
  const portfolioMutation = useMutation({
    mutationFn: async (projectData: any) => {
      return apiRequest('POST', '/api/portfolio', projectData);
    },
    onSuccess: () => {
      toast({
        title: "Project added",
        description: "Your portfolio project has been added successfully"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio', user?.id] });
      // Reset new project form
      setNewProject({
        title: '',
        projectType: '',
        role: '',
        description: '',
        projectDate: '',
        duration: '',
        location: '',
        images: []
      });
    },
    onError: (error) => {
      toast({
        title: "Error adding project",
        description: "Please try again later",
        variant: "destructive"
      });
      console.error('Error adding project:', error);
    }
  });
  
  // Initialize form with existing data
  useEffect(() => {
    if (profileData) {
      setCompanyName(profileData.companyName || '');
      setExperience(profileData.experience || '3-5 years');
      setTeamSize(profileData.teamSize || '6-10 workers');
      setCity(profileData.city || '');
      setState(profileData.state || '');
      setWillingToTravel(profileData.willingToTravel || []);
      setLanguagesSpoken(profileData.languagesSpoken || []);
      setSelectedSpecializations(profileData.specializations || {});
      setSelectedProjectTypes(profileData.projectTypes || []);
      setMaxProjectValue(profileData.maxProjectValue || '');
    }
  }, [profileData]);
  
  // Initialize portfolio data
  useEffect(() => {
    if (portfolioData) {
      setPortfolioProjects(portfolioData);
    }
  }, [portfolioData]);
  
  // Handle adding a new location
  const handleAddLocation = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && newLocation.trim()) {
      e.preventDefault();
      if (!willingToTravel.includes(newLocation.trim())) {
        setWillingToTravel([...willingToTravel, newLocation.trim()]);
      }
      setNewLocation('');
    }
  };
  
  // Handle removing a location
  const handleRemoveLocation = (location: string) => {
    setWillingToTravel(willingToTravel.filter(loc => loc !== location));
  };
  
  // Handle adding a new language
  const handleAddLanguage = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && newLanguage.trim()) {
      e.preventDefault();
      if (!languagesSpoken.includes(newLanguage.trim())) {
        setLanguagesSpoken([...languagesSpoken, newLanguage.trim()]);
      }
      setNewLanguage('');
    }
  };
  
  // Handle removing a language
  const handleRemoveLanguage = (language: string) => {
    setLanguagesSpoken(languagesSpoken.filter(lang => lang !== language));
  };
  
  // Handle specialization selection
  const handleSpecializationToggle = (category: string, skill: string) => {
    const currentSkills = selectedSpecializations[category] || [];
    
    if (currentSkills.includes(skill)) {
      // Remove skill
      setSelectedSpecializations({
        ...selectedSpecializations,
        [category]: currentSkills.filter(s => s !== skill)
      });
    } else {
      // Add skill
      setSelectedSpecializations({
        ...selectedSpecializations,
        [category]: [...currentSkills, skill]
      });
    }
  };
  
  // Handle project type selection
  const handleProjectTypeToggle = (projectTypeId: string) => {
    if (selectedProjectTypes.includes(projectTypeId)) {
      setSelectedProjectTypes(selectedProjectTypes.filter(type => type !== projectTypeId));
    } else {
      setSelectedProjectTypes([...selectedProjectTypes, projectTypeId]);
    }
  };
  
  // Handle save profile
  const handleSaveProfile = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to save your profile",
        variant: "destructive"
      });
      return;
    }
    
    // Validate required fields
    if (!city || !state || !experience || !teamSize) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    
    const profileFormData = {
      ...(profileData || {}),
      userId: user.id,
      companyName,
      experience,
      teamSize,
      city,
      state,
      willingToTravel,
      languagesSpoken,
      specializations: selectedSpecializations,
      projectTypes: selectedProjectTypes,
      maxProjectValue
    };
    
    profileMutation.mutate(profileFormData);
  };
  
  // Handle add portfolio project
  const handleAddPortfolioProject = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to add portfolio projects",
        variant: "destructive"
      });
      return;
    }
    
    // Validate required fields
    if (!newProject.title || !newProject.projectType || !newProject.role || !newProject.description || !newProject.projectDate || !newProject.duration) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    
    const projectData = {
      ...newProject,
      contractorId: user.id
    };
    
    portfolioMutation.mutate(projectData);
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader className="bg-primary-600 text-white p-4 flex flex-row items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" className="text-white mr-2" onClick={() => setLocation('/dashboard')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-lg font-bold">Contractor Profile</h2>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="bg-white text-primary-600 hover:bg-primary-50 hover:text-primary-700"
          onClick={handleSaveProfile}
          disabled={profileMutation.isPending}
        >
          {profileMutation.isPending ? 'Saving...' : 'Save'}
        </Button>
      </CardHeader>
      
      {/* Profile Header */}
      <div className="p-6 flex flex-col sm:flex-row gap-4 border-b">
        <div className="flex-shrink-0">
          <div className="w-24 h-24 bg-gray-200 rounded-full relative flex items-center justify-center overflow-hidden">
            <span className="text-2xl font-medium text-gray-600">
              {user?.fullName?.split(' ').map(n => n[0]).join('') || 'RK'}
            </span>
            <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-20 flex items-center justify-center cursor-pointer transition">
              <Camera className="text-white text-2xl opacity-0 hover:opacity-100" />
            </div>
          </div>
        </div>
        <div className="flex-grow">
          <h3 className="font-bold text-xl text-gray-900">{user?.fullName || 'Contractor Name'}</h3>
          <p className="text-sm text-gray-600">Contractor ID: {user?.id ? `CON${new Date().getFullYear()}${String(user.id).padStart(4, '0')}` : 'New Contractor'}</p>
          <div className="flex items-center mt-1">
            <span className="text-yellow-500 mr-1">★</span>
            <span className="text-sm">New Contractor</span>
          </div>
          <button className="mt-2 text-sm text-primary-600 hover:text-primary-700 flex items-center">
            <Camera className="h-4 w-4 mr-1" /> Change Profile Photo
          </button>
        </div>
      </div>
      
      {/* Tabs Navigation */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 p-0">
          <TabsTrigger value="basic" className="rounded-none border-b-2 data-[state=active]:border-primary-600 data-[state=active]:text-primary-600">
            Basic Info
          </TabsTrigger>
          <TabsTrigger value="specialization" className="rounded-none border-b-2 data-[state=active]:border-primary-600 data-[state=active]:text-primary-600">
            Specializations
          </TabsTrigger>
          <TabsTrigger value="portfolio" className="rounded-none border-b-2 data-[state=active]:border-primary-600 data-[state=active]:text-primary-600">
            Portfolio
          </TabsTrigger>
        </TabsList>
        
        {/* Basic Info Tab */}
        <TabsContent value="basic" className="p-6 space-y-6">
          <div>
            <Label htmlFor="companyName">Company/Team Name</Label>
            <Input 
              id="companyName"
              value={companyName} 
              onChange={(e) => setCompanyName(e.target.value)} 
              placeholder="e.g. Rajesh Construction Team"
            />
          </div>
          
          <div>
            <Label htmlFor="experience">Years of Experience</Label>
            <Select 
              value={experience}
              onValueChange={setExperience}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select experience" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Less than 1 year">Less than 1 year</SelectItem>
                <SelectItem value="1-3 years">1-3 years</SelectItem>
                <SelectItem value="3-5 years">3-5 years</SelectItem>
                <SelectItem value="5-10 years">5-10 years</SelectItem>
                <SelectItem value="10+ years">10+ years</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="teamSize">Team Size</Label>
            <Select 
              value={teamSize}
              onValueChange={setTeamSize}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select team size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1-5 workers">1-5 workers</SelectItem>
                <SelectItem value="6-10 workers">6-10 workers</SelectItem>
                <SelectItem value="11-20 workers">11-20 workers</SelectItem>
                <SelectItem value="21-50 workers">21-50 workers</SelectItem>
                <SelectItem value="50+ workers">50+ workers</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Primary Location</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select 
                value={city}
                onValueChange={setCity}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select City" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mumbai">Mumbai</SelectItem>
                  <SelectItem value="Delhi">Delhi</SelectItem>
                  <SelectItem value="Bangalore">Bangalore</SelectItem>
                  <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                  <SelectItem value="Chennai">Chennai</SelectItem>
                  <SelectItem value="Kolkata">Kolkata</SelectItem>
                  <SelectItem value="Pune">Pune</SelectItem>
                </SelectContent>
              </Select>
              <Select 
                value={state}
                onValueChange={setState}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select State" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Maharashtra">Maharashtra</SelectItem>
                  <SelectItem value="Delhi">Delhi</SelectItem>
                  <SelectItem value="Karnataka">Karnataka</SelectItem>
                  <SelectItem value="Telangana">Telangana</SelectItem>
                  <SelectItem value="Tamil Nadu">Tamil Nadu</SelectItem>
                  <SelectItem value="West Bengal">West Bengal</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label>Willing to Travel To</Label>
            <div className="border rounded p-2 mb-2 flex flex-wrap gap-1">
              {willingToTravel.map((location, index) => (
                <Badge key={index} variant="secondary" className="bg-primary-100 text-primary-800 border-none">
                  {location}
                  <button 
                    type="button"
                    className="ml-1 text-primary-600 hover:text-primary-800"
                    onClick={() => handleRemoveLocation(location)}
                  >
                    ×
                  </button>
                </Badge>
              ))}
              <Input 
                type="text"
                className="flex-grow p-1 border-0 text-sm focus:outline-none focus:ring-0"
                placeholder="Add more states..."
                value={newLocation}
                onChange={(e) => setNewLocation(e.target.value)}
                onKeyDown={handleAddLocation}
              />
            </div>
          </div>
          
          <div>
            <Label>Languages Spoken</Label>
            <div className="border rounded p-2 mb-2 flex flex-wrap gap-1">
              {languagesSpoken.map((language, index) => (
                <Badge key={index} variant="secondary" className="bg-primary-100 text-primary-800 border-none">
                  {language}
                  <button 
                    type="button"
                    className="ml-1 text-primary-600 hover:text-primary-800"
                    onClick={() => handleRemoveLanguage(language)}
                  >
                    ×
                  </button>
                </Badge>
              ))}
              <Input 
                type="text"
                className="flex-grow p-1 border-0 text-sm focus:outline-none focus:ring-0"
                placeholder="Add more languages..."
                value={newLanguage}
                onChange={(e) => setNewLanguage(e.target.value)}
                onKeyDown={handleAddLanguage}
              />
            </div>
          </div>
        </TabsContent>
        
        {/* Specializations Tab */}
        <TabsContent value="specialization" className="p-6">
          <p className="text-sm text-gray-600 mb-6">Select your team's specializations to help match you with the right projects.</p>
          
          {specializations.map((group, index) => (
            <div key={index} className="mb-6">
              <h3 className="font-medium mb-2">{group.category}</h3>
              <div className="grid grid-cols-2 gap-2">
                {group.skills.map((skill, skillIndex) => {
                  const isChecked = (selectedSpecializations[group.category] || []).includes(skill);
                  return (
                    <div key={skillIndex} className="flex items-center">
                      <Checkbox 
                        id={`skill-${index}-${skillIndex}`}
                        checked={isChecked}
                        onCheckedChange={() => handleSpecializationToggle(group.category, skill)}
                        className="mr-2"
                      />
                      <Label 
                        htmlFor={`skill-${index}-${skillIndex}`}
                        className="text-sm cursor-pointer"
                      >
                        {skill}
                      </Label>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
          
          <div className="mb-6">
            <h3 className="font-medium mb-2">Project Types Handled</h3>
            <div className="grid grid-cols-1 gap-2">
              {projectTypes.map((type, index) => (
                <div key={index} className="flex items-center">
                  <Checkbox 
                    id={`project-${type.id}`}
                    checked={selectedProjectTypes.includes(type.id)}
                    onCheckedChange={() => handleProjectTypeToggle(type.id)}
                    className="mr-2"
                  />
                  <Label 
                    htmlFor={`project-${type.id}`}
                    className="text-sm cursor-pointer"
                  >
                    {type.name}
                  </Label>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="font-medium mb-2">Maximum Project Value Handled (Optional)</h3>
            <Select 
              value={maxProjectValue}
              onValueChange={setMaxProjectValue}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select max project value" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Up to ₹5 lakhs">Up to ₹5 lakhs</SelectItem>
                <SelectItem value="₹5 lakhs - ₹25 lakhs">₹5 lakhs - ₹25 lakhs</SelectItem>
                <SelectItem value="₹25 lakhs - ₹1 crore">₹25 lakhs - ₹1 crore</SelectItem>
                <SelectItem value="₹1 crore - ₹5 crores">₹1 crore - ₹5 crores</SelectItem>
                <SelectItem value="Above ₹5 crores">Above ₹5 crores</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex justify-end">
            <Button onClick={handleSaveProfile} disabled={profileMutation.isPending}>
              {profileMutation.isPending ? 'Saving...' : 'Save Specializations'}
            </Button>
          </div>
        </TabsContent>
        
        {/* Portfolio Tab */}
        <TabsContent value="portfolio" className="p-6">
          <p className="text-sm text-gray-600 mb-6">Add photos and details of your previous work to showcase your skills and experience.</p>
          
          <div className="mb-6 border rounded-lg p-4">
            <h3 className="font-medium mb-4">Add Project</h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="projectTitle">Project Title</Label>
                <Input 
                  id="projectTitle"
                  value={newProject.title}
                  onChange={(e) => setNewProject({...newProject, title: e.target.value})}
                  placeholder="e.g. Prestige Apartments Construction"
                />
              </div>
              
              <div>
                <Label htmlFor="projectType">Project Type</Label>
                <Select 
                  value={newProject.projectType}
                  onValueChange={(value) => setNewProject({...newProject, projectType: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Project Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Residential Building">Residential Building</SelectItem>
                    <SelectItem value="Commercial Building">Commercial Building</SelectItem>
                    <SelectItem value="Road Construction">Road Construction</SelectItem>
                    <SelectItem value="Bridge Construction">Bridge Construction</SelectItem>
                    <SelectItem value="Industrial Structure">Industrial Structure</SelectItem>
                    <SelectItem value="Plant Civil Works">Plant Civil Works</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="projectRole">Your Role</Label>
                <Input 
                  id="projectRole"
                  value={newProject.role}
                  onChange={(e) => setNewProject({...newProject, role: e.target.value})}
                  placeholder="e.g. Masonry Contractor"
                />
              </div>
              
              <div>
                <Label htmlFor="projectDescription">Project Description</Label>
                <Textarea 
                  id="projectDescription"
                  value={newProject.description}
                  onChange={(e) => setNewProject({...newProject, description: e.target.value})}
                  placeholder="Describe the project and your contribution..."
                  className="h-20"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="projectDate">Project Date</Label>
                  <Input 
                    id="projectDate"
                    type="month"
                    value={newProject.projectDate}
                    onChange={(e) => setNewProject({...newProject, projectDate: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="projectDuration">Duration</Label>
                  <Select 
                    value={newProject.duration}
                    onValueChange={(value) => setNewProject({...newProject, duration: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Duration: 1 month">Duration: 1 month</SelectItem>
                      <SelectItem value="Duration: 2 months">Duration: 2 months</SelectItem>
                      <SelectItem value="Duration: 3 months">Duration: 3 months</SelectItem>
                      <SelectItem value="Duration: 6 months">Duration: 6 months</SelectItem>
                      <SelectItem value="Duration: 1 year">Duration: 1 year</SelectItem>
                      <SelectItem value="Duration: 1+ years">Duration: 1+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="projectLocation">Location</Label>
                <Input 
                  id="projectLocation"
                  value={newProject.location}
                  onChange={(e) => setNewProject({...newProject, location: e.target.value})}
                  placeholder="e.g. Bangalore, Karnataka"
                />
              </div>
              
              <div>
                <Label>Project Photos</Label>
                <div className="border border-dashed rounded-md p-4 text-center">
                  <Camera className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500">
                    Drop your images here or click to upload
                    <br />
                    <span className="text-xs">Max 5 images, 2MB each</span>
                  </p>
                  <Button variant="outline" size="sm" className="mt-2">
                    Upload Photos
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  onClick={handleAddPortfolioProject}
                  disabled={portfolioMutation.isPending}
                >
                  {portfolioMutation.isPending ? 'Adding...' : 'Add Project'}
                </Button>
              </div>
            </div>
          </div>
          
          {/* Portfolio Projects List */}
          {portfolioProjects.length > 0 ? (
            <div className="space-y-4">
              <h3 className="font-medium">Your Portfolio ({portfolioProjects.length})</h3>
              
              {portfolioProjects.map((project, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex justify-between mb-2">
                    <h4 className="font-medium">{project.title}</h4>
                    <span className="text-sm text-gray-500">{project.projectDate}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{project.projectType} • {project.location}</p>
                  <p className="text-sm mb-2">{project.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">{project.duration}</span>
                    <div>
                      <Button variant="outline" size="sm" className="mr-2">Edit</Button>
                      <Button variant="destructive" size="sm">Delete</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No portfolio projects added yet.</p>
              <p className="text-sm">Add your first project to showcase your work.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      <CardFooter className="flex justify-end gap-3 pt-6 border-t">
        <Button variant="outline" onClick={() => setLocation('/dashboard')}>
          Cancel
        </Button>
        <Button onClick={handleSaveProfile} disabled={profileMutation.isPending}>
          {profileMutation.isPending ? 'Saving...' : 'Save Profile'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ContractorProfile;
