import React, { useState, useEffect } from 'react';
import { useLocation, useSearch } from 'wouter';
import { Search, MapPin, ChevronDown, ChevronUp, Filter, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import ProjectCard from '@/components/ProjectCard';
import { queryClient } from '@/lib/queryClient';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const ProjectSearch = () => {
  const [_, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  
  // Filter states
  const [showFilters, setShowFilters] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [projectType, setProjectType] = useState(params.get('type') || '');
  const [subCategory, setSubCategory] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [budgetMin, setBudgetMin] = useState<string>('');
  const [budgetMax, setBudgetMax] = useState<string>('');
  const [duration, setDuration] = useState('');
  const [projectStatus, setProjectStatus] = useState<string[]>(['open']);
  const [sortBy, setSortBy] = useState('newest');
  
  // Pagination
  const [page, setPage] = useState(1);
  const projectsPerPage = 5;
  
  // Project types
  const projectTypes = [
    { id: 'all', name: 'All Project Types' },
    { id: 'building', name: 'Building Projects' },
    { id: 'infrastructure', name: 'Infrastructure Projects' },
    { id: 'industrial', name: 'Industrial Projects' },
    { id: 'specialized', name: 'Specialized Projects' }
  ];
  
  // Sub-categories based on selected project type
  const subCategories: Record<string, { id: string, name: string }[]> = {
    building: [
      { id: 'residential', name: 'Residential Buildings' },
      { id: 'commercial', name: 'Commercial Buildings' },
      { id: 'institutional', name: 'Institutional Buildings' }
    ],
    infrastructure: [
      { id: 'roads', name: 'Roads/Highways' },
      { id: 'bridges', name: 'Bridges/Culverts' },
      { id: 'drains', name: 'Drains/Sewage Systems' }
    ],
    industrial: [
      { id: 'plant_civil', name: 'Plant Civil Works' },
      { id: 'industrial_buildings', name: 'Industrial Buildings' },
      { id: 'mechanical', name: 'Mechanical Structures' },
      { id: 'tankage', name: 'Tankage Works' },
      { id: 'piping', name: 'Piping Systems' },
      { id: 'electrical', name: 'Electrical Installations' }
    ],
    specialized: [
      { id: 'renovation', name: 'Renovation/Repairs' },
      { id: 'interior', name: 'Interior Finishing' },
      { id: 'landscaping', name: 'Landscaping' }
    ]
  };
  
  // Skills options
  const skills = [
    'Masonry', 'Plastering', 'Carpentry', 'Painting', 'Plumbing', 'Electrical',
    'Concrete Work', 'Road Construction', 'Bridge Construction', 'Drainage',
    'Structural Steel', 'Waterproofing', 'Interior Finishing', 'Landscaping'
  ];
  
  // Effect to set project type from URL params
  useEffect(() => {
    const typeParam = params.get('type');
    if (typeParam) {
      setProjectType(typeParam);
    }
  }, [params]);
  
  // Fetch projects
  const { data: projects, isLoading, error } = useQuery({
    queryKey: ['/api/projects', projectType, subCategory, city, state, selectedSkills.join(','), projectStatus.join(',')],
    queryFn: async () => {
      const queryParams = new URLSearchParams();
      
      if (projectType && projectType !== 'all') queryParams.append('projectType', projectType);
      if (subCategory) queryParams.append('subCategory', subCategory);
      if (city) queryParams.append('city', city);
      if (state) queryParams.append('state', state);
      if (selectedSkills.length) queryParams.append('skills', selectedSkills.join(','));
      if (projectStatus.length) queryParams.append('status', projectStatus.join(','));
      
      const res = await fetch(`/api/projects?${queryParams.toString()}`);
      if (!res.ok) {
        throw new Error('Failed to fetch projects');
      }
      return res.json();
    }
  });
  
  // Toggle filter selection
  const toggleSkill = (skill: string) => {
    setSelectedSkills(prev => 
      prev.includes(skill) 
        ? prev.filter(s => s !== skill) 
        : [...prev, skill]
    );
  };
  
  // Toggle project status
  const toggleStatus = (status: string) => {
    setProjectStatus(prev => 
      prev.includes(status) 
        ? prev.filter(s => s !== status) 
        : [...prev, status]
    );
  };
  
  // Apply filters
  const applyFilters = () => {
    // Refresh projects query with filters
    queryClient.invalidateQueries({ 
      queryKey: ['/api/projects', projectType, subCategory, city, state, selectedSkills.join(','), projectStatus.join(',')]
    });
    setPage(1);
  };
  
  // Reset filters
  const resetFilters = () => {
    setProjectType('');
    setSubCategory('');
    setCity('');
    setState('');
    setSelectedSkills([]);
    setBudgetMin('');
    setBudgetMax('');
    setDuration('');
    setProjectStatus(['open']);
    queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    setPage(1);
  };
  
  // Filter projects by search term
  const filteredProjects = projects ? projects.filter(project => {
    if (!searchTerm) return true;
    const lowerSearchTerm = searchTerm.toLowerCase();
    return (
      project.title.toLowerCase().includes(lowerSearchTerm) ||
      project.description.toLowerCase().includes(lowerSearchTerm) ||
      project.area?.toLowerCase().includes(lowerSearchTerm) ||
      project.city.toLowerCase().includes(lowerSearchTerm) ||
      project.state.toLowerCase().includes(lowerSearchTerm) ||
      project.skills.some(skill => skill.toLowerCase().includes(lowerSearchTerm))
    );
  }) : [];
  
  // Sort projects
  const sortedProjects = [...(filteredProjects || [])].sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case 'oldest':
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      case 'budget_high':
        return (b.budgetMax || 0) - (a.budgetMax || 0);
      case 'budget_low':
        return (a.budgetMin || 0) - (b.budgetMin || 0);
      case 'duration_short':
        return a.durationValue - b.durationValue;
      case 'duration_long':
        return b.durationValue - a.durationValue;
      default:
        return 0;
    }
  });
  
  // Paginate projects
  const paginatedProjects = sortedProjects.slice(
    (page - 1) * projectsPerPage,
    page * projectsPerPage
  );
  
  const totalPages = Math.ceil(sortedProjects.length / projectsPerPage);

  return (
    <Card className="max-w-4xl mx-auto">
      <div className="bg-primary-600 text-white px-6 py-4">
        <h2 className="text-lg font-bold">Find Projects</h2>
      </div>
      
      {/* Search Bar */}
      <div className="p-3 bg-gray-50 flex items-center">
        <Input 
          type="text" 
          className="flex-grow rounded-r-none"
          placeholder="Search by keywords, location, etc."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <Button className="rounded-l-none">
          <Search className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Location & Filter */}
      <div className="p-3 border-b flex flex-wrap justify-between items-center">
        <div className="flex items-center mb-2 sm:mb-0">
          <span className="text-sm font-medium mr-2">Current Location: </span>
          <span className="text-sm text-primary-600 flex items-center">
            <MapPin className="h-4 w-4 mr-1" /> Bangalore, KA
          </span>
        </div>
        <Button 
          variant="ghost" 
          size="sm"
          className="text-primary-600"
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="h-4 w-4 mr-1" />
          Filter
          {showFilters ? <ChevronUp className="h-4 w-4 ml-1" /> : <ChevronDown className="h-4 w-4 ml-1" />}
        </Button>
      </div>
      
      {/* Filters Panel */}
      {showFilters && (
        <div className="p-3 bg-gray-50 border-b">
          <h3 className="font-medium mb-2">Filter Projects</h3>
          
          <div className="space-y-3">
            <div>
              <Label className="text-sm font-medium mb-1">Project Type</Label>
              <Select 
                value={projectType}
                onValueChange={setProjectType}
              >
                <SelectTrigger className="bg-white">
                  <SelectValue placeholder="All Project Types" />
                </SelectTrigger>
                <SelectContent>
                  {projectTypes.map(type => (
                    <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {projectType && projectType !== 'all' && (
              <div>
                <Label className="text-sm font-medium mb-1">Sub-Category</Label>
                <Select 
                  value={subCategory}
                  onValueChange={setSubCategory}
                >
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Categories</SelectItem>
                    {subCategories[projectType]?.map(category => (
                      <SelectItem key={category.id} value={category.id}>{category.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div>
              <Label className="text-sm font-medium mb-1">Location</Label>
              <div className="grid grid-cols-2 gap-2">
                <Select 
                  value={city}
                  onValueChange={setCity}
                >
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="Any City" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any City</SelectItem>
                    <SelectItem value="Mumbai">Mumbai</SelectItem>
                    <SelectItem value="Delhi">Delhi</SelectItem>
                    <SelectItem value="Bangalore">Bangalore</SelectItem>
                    <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                    <SelectItem value="Chennai">Chennai</SelectItem>
                    <SelectItem value="Kolkata">Kolkata</SelectItem>
                    <SelectItem value="Pune">Pune</SelectItem>
                  </SelectContent>
                </Select>
                <Select 
                  value={state}
                  onValueChange={setState}
                >
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="Any State" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any State</SelectItem>
                    <SelectItem value="Maharashtra">Maharashtra</SelectItem>
                    <SelectItem value="Delhi">Delhi</SelectItem>
                    <SelectItem value="Karnataka">Karnataka</SelectItem>
                    <SelectItem value="Telangana">Telangana</SelectItem>
                    <SelectItem value="Tamil Nadu">Tamil Nadu</SelectItem>
                    <SelectItem value="West Bengal">West Bengal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-1">Skills Required</Label>
              <div className="grid grid-cols-2 gap-2">
                {skills.slice(0, 6).map(skill => (
                  <div key={skill} className="flex items-center">
                    <Checkbox 
                      id={`skill-${skill}`} 
                      checked={selectedSkills.includes(skill)}
                      onCheckedChange={() => toggleSkill(skill)}
                      className="mr-2" 
                    />
                    <Label htmlFor={`skill-${skill}`} className="text-sm cursor-pointer">{skill}</Label>
                  </div>
                ))}
              </div>
              {skills.length > 6 && (
                <Button variant="link" size="sm" className="text-primary-600 p-0 h-auto mt-1">
                  Show more skills
                </Button>
              )}
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium mb-1">Budget Range</Label>
                <div className="flex">
                  <span className="p-2 border border-r-0 rounded-l bg-white">₹</span>
                  <Input 
                    type="number" 
                    className="w-full rounded-none border-l-0"
                    placeholder="Min"
                    value={budgetMin}
                    onChange={(e) => setBudgetMin(e.target.value)}
                  />
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium mb-1">&nbsp;</Label>
                <div className="flex">
                  <span className="p-2 border border-r-0 rounded-l bg-white">₹</span>
                  <Input 
                    type="number" 
                    className="w-full rounded-none border-l-0"
                    placeholder="Max"
                    value={budgetMax}
                    onChange={(e) => setBudgetMax(e.target.value)}
                  />
                </div>
              </div>
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-1">Duration</Label>
              <Select 
                value={duration}
                onValueChange={setDuration}
              >
                <SelectTrigger className="bg-white">
                  <SelectValue placeholder="Any Duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any Duration</SelectItem>
                  <SelectItem value="less_than_1_week">Less than 1 week</SelectItem>
                  <SelectItem value="1_4_weeks">1-4 weeks</SelectItem>
                  <SelectItem value="1_3_months">1-3 months</SelectItem>
                  <SelectItem value="3_6_months">3-6 months</SelectItem>
                  <SelectItem value="6_plus_months">6+ months</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-1">Project Status</Label>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center">
                  <Checkbox 
                    id="status-open" 
                    checked={projectStatus.includes('open')}
                    onCheckedChange={() => toggleStatus('open')}
                    className="mr-2" 
                  />
                  <Label htmlFor="status-open" className="text-sm cursor-pointer">Open</Label>
                </div>
                <div className="flex items-center">
                  <Checkbox 
                    id="status-awarded" 
                    checked={projectStatus.includes('awarded')}
                    onCheckedChange={() => toggleStatus('awarded')}
                    className="mr-2" 
                  />
                  <Label htmlFor="status-awarded" className="text-sm cursor-pointer">Awarded</Label>
                </div>
                <div className="flex items-center">
                  <Checkbox 
                    id="status-ongoing" 
                    checked={projectStatus.includes('ongoing')}
                    onCheckedChange={() => toggleStatus('ongoing')}
                    className="mr-2" 
                  />
                  <Label htmlFor="status-ongoing" className="text-sm cursor-pointer">Ongoing</Label>
                </div>
                <div className="flex items-center">
                  <Checkbox 
                    id="status-completed" 
                    checked={projectStatus.includes('completed')}
                    onCheckedChange={() => toggleStatus('completed')}
                    className="mr-2" 
                  />
                  <Label htmlFor="status-completed" className="text-sm cursor-pointer">Completed</Label>
                </div>
              </div>
            </div>
            
            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={resetFilters}>Reset Filters</Button>
              <Button className="flex-1" onClick={applyFilters}>Apply Filters</Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Quick Filters */}
      <div className="p-3 overflow-x-auto">
        <div className="flex gap-2">
          <Badge variant="secondary" className="whitespace-nowrap px-3 py-1 bg-primary-100 text-primary-800 rounded-full text-sm">
            <MapPin className="h-3 w-3 mr-1" /> Near Me
          </Badge>
          <Badge variant="outline" className="whitespace-nowrap px-3 py-1 rounded-full text-sm cursor-pointer hover:bg-gray-50">
            <Clock className="h-3 w-3 mr-1" /> New Projects
          </Badge>
          <Badge variant="outline" className="whitespace-nowrap px-3 py-1 rounded-full text-sm cursor-pointer hover:bg-gray-50">
            Residential
          </Badge>
          <Badge variant="outline" className="whitespace-nowrap px-3 py-1 rounded-full text-sm cursor-pointer hover:bg-gray-50">
            Commercial
          </Badge>
          <Badge variant="outline" className="whitespace-nowrap px-3 py-1 rounded-full text-sm cursor-pointer hover:bg-gray-50">
            High Budget
          </Badge>
        </div>
      </div>
      
      {/* Search Results */}
      <div className="p-3">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-medium">
            {isLoading ? 'Loading projects...' : 
             `${sortedProjects.length} Projects Found`}
          </h3>
          <Select 
            value={sortBy}
            onValueChange={setSortBy}
          >
            <SelectTrigger className="text-sm h-8 w-[180px] bg-gray-50">
              <SelectValue placeholder="Sort: Newest First" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Sort: Newest First</SelectItem>
              <SelectItem value="oldest">Sort: Oldest First</SelectItem>
              <SelectItem value="budget_high">Sort: Budget: High to Low</SelectItem>
              <SelectItem value="budget_low">Sort: Budget: Low to High</SelectItem>
              <SelectItem value="duration_short">Sort: Duration: Short to Long</SelectItem>
              <SelectItem value="duration_long">Sort: Duration: Long to Short</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <Card key={i} className="w-full">
                <CardContent className="p-0 h-40 animate-pulse bg-gray-100"></CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-red-500">
              Error loading projects. Please try again later.
            </p>
          </div>
        ) : paginatedProjects.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No projects found matching your criteria.</p>
            <Button 
              variant="link" 
              className="mt-2"
              onClick={resetFilters}
            >
              Clear filters and try again
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {paginatedProjects.map(project => (
              <ProjectCard key={project.id} project={project} />
            ))}
            
            {/* Pagination */}
            {totalPages > 1 && (
              <Pagination className="mt-6">
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        if (page > 1) setPage(page - 1);
                      }}
                      className={page === 1 ? 'pointer-events-none opacity-50' : ''}
                    />
                  </PaginationItem>
                  
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(pageNum => (
                    <PaginationItem key={pageNum}>
                      <PaginationLink 
                        href="#" 
                        onClick={(e) => {
                          e.preventDefault();
                          setPage(pageNum);
                        }}
                        isActive={page === pageNum}
                      >
                        {pageNum}
                      </PaginationLink>
                    </PaginationItem>
                  ))}
                  
                  <PaginationItem>
                    <PaginationNext 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        if (page < totalPages) setPage(page + 1);
                      }}
                      className={page === totalPages ? 'pointer-events-none opacity-50' : ''}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            )}
          </div>
        )}
      </div>
    </Card>
  );
};

export default ProjectSearch;
