import React from 'react';
import { MapPin, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useLocation } from 'wouter';

interface ProjectCardProps {
  project: {
    id: number;
    title: string;
    projectType: string;
    subCategory: string;
    area: string;
    city: string;
    state: string;
    description: string;
    budgetMin: number;
    budgetMax: number;
    durationValue: number;
    durationType: string;
    skills: string[];
    status: string;
    createdAt: Date;
  };
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  const [_, setLocation] = useLocation();
  
  // Format budget display
  const formatBudget = (value: number) => {
    if (value >= 10000000) {
      return `₹${(value / 10000000).toFixed(1)} Cr`;
    } else if (value >= 100000) {
      return `₹${(value / 100000).toFixed(1)} Lakhs`;
    } else if (value >= 1000) {
      return `₹${(value / 1000).toFixed(1)}K`;
    }
    return `₹${value}`;
  };
  
  // Calculate days since posted
  const daysAgo = () => {
    const now = new Date();
    const createdAt = new Date(project.createdAt);
    const diffTime = Math.abs(now.getTime() - createdAt.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    return `${diffDays} days ago`;
  };
  
  // Format project type display
  const getProjectTypeIcon = () => {
    switch (project.projectType) {
      case 'building':
        return '🏢';
      case 'infrastructure':
        return '🛣️';
      case 'industrial':
        return '🏭';
      case 'specialized':
        return '🔧';
      default:
        return '📋';
    }
  };
  
  // Format status badge color
  const getStatusColor = () => {
    switch (project.status) {
      case 'open':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'awarded':
        return 'bg-blue-100 text-blue-800';
      case 'ongoing':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition">
      <div className="bg-primary-50 p-3 flex justify-between items-center">
        <span className="font-medium text-gray-900">{project.title}</span>
        <span className={`${getStatusColor()} text-xs px-2 py-1 rounded-full font-medium capitalize`}>
          {project.status}
        </span>
      </div>
      <div className="p-4">
        <div className="flex justify-between mb-3">
          <div className="text-sm text-gray-600">
            <div className="flex items-center mb-1">
              <MapPin className="h-4 w-4 mr-1" /> {project.area}, {project.city}
            </div>
            <div className="flex items-center">
              <span className="mr-1">{getProjectTypeIcon()}</span> {project.subCategory}
            </div>
          </div>
          <div className="text-right">
            <div className="font-medium text-gray-900">
              {formatBudget(project.budgetMin)}-{formatBudget(project.budgetMax)}
            </div>
            <div className="text-sm text-gray-600">{project.durationValue} {project.durationType}</div>
          </div>
        </div>
        <p className="text-sm mb-3 text-gray-700 line-clamp-2">{project.description}</p>
        <div className="flex flex-wrap gap-1 mb-3">
          {project.skills.slice(0, 3).map((skill, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {skill}
            </Badge>
          ))}
          {project.skills.length > 3 && (
            <Badge variant="secondary" className="text-xs">
              +{project.skills.length - 3} more
            </Badge>
          )}
        </div>
        <div className="flex justify-between items-center">
          <div className="text-xs text-gray-500 flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            Posted {daysAgo()}
          </div>
          <Button 
            size="sm" 
            onClick={() => setLocation(`/project/${project.id}`)}
            className="rounded-full"
          >
            View Details
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
