import React from 'react';
import { Building2, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';
import { Link } from 'wouter';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-8 mt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Building2 className="h-6 w-6 mr-2" />
              <h3 className="text-lg font-medium">ConstructConnect</h3>
            </div>
            <p className="text-gray-400 text-sm">Connecting contractors with construction projects across India.</p>
          </div>
          <div>
            <h4 className="font-medium mb-3">For Contractors</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/project-search" className="hover:text-white">Find Projects</Link></li>
              <li><Link href="/contractor-profile" className="hover:text-white">Create Profile</Link></li>
              <li><Link href="/project-search" className="hover:text-white">Project Matching</Link></li>
              <li><Link href="#" className="hover:text-white">How It Works</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-3">For Project Owners</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/create-project" className="hover:text-white">Post a Project</Link></li>
              <li><Link href="/contractor-profile" className="hover:text-white">Find Contractors</Link></li>
              <li><Link href="#" className="hover:text-white">Success Stories</Link></li>
              <li><Link href="#" className="hover:text-white">Pricing</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-3">Company</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="#" className="hover:text-white">About Us</Link></li>
              <li><Link href="#" className="hover:text-white">Careers</Link></li>
              <li><Link href="#" className="hover:text-white">Contact Us</Link></li>
              <li><Link href="#" className="hover:text-white">Privacy Policy</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-6 border-t border-gray-700 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-400">© 2023 ConstructConnect. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-white">
              <Facebook className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Twitter className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Linkedin className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Instagram className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
