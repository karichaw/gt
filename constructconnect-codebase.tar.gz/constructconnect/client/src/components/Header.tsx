import React from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Building2, Bell, Menu, X } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from 'react';

const Header = () => {
  const [location, setLocation] = useLocation();
  const { isAuthenticated, user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <Building2 className="text-primary h-6 w-6 mr-2" />
              <span className="font-bold text-xl text-gray-900">ConstructConnect</span>
            </Link>
            <nav className="hidden md:ml-8 md:flex md:space-x-6">
              <Link href="/project-search" className={`border-b-2 ${location === '/project-search' ? 'border-primary text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} px-1 py-2 text-sm font-medium`}>
                Projects
              </Link>
              <Link href="/contractor-profile" className={`border-b-2 ${location === '/contractor-profile' ? 'border-primary text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} px-1 py-2 text-sm font-medium`}>
                Contractors
              </Link>
              {isAuthenticated && (
                <>
                  <Link href="/dashboard" className={`border-b-2 ${location === '/dashboard' ? 'border-primary text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} px-1 py-2 text-sm font-medium`}>
                    Dashboard
                  </Link>
                </>
              )}
            </nav>
          </div>
          <div className="flex items-center">
            {isAuthenticated ? (
              <>
                <button className="p-2 rounded-full text-gray-500 hover:text-gray-700">
                  <Bell className="h-5 w-5" />
                </button>
                <div className="ml-4 relative flex items-center">
                  <DropdownMenu>
                    <DropdownMenuTrigger className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center">
                        <span className="text-primary-700 font-medium text-sm">
                          {user?.fullName?.split(' ').map(n => n[0]).join('') || 'U'}
                        </span>
                      </div>
                      <span className="ml-2 text-sm font-medium text-gray-700 hidden md:block">
                        {user?.fullName || 'User'}
                      </span>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>My Account</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard">Dashboard</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/contractor-profile">Profile</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleLogout}>
                        Log Out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <Button variant="outline" onClick={() => setLocation('/contractor-profile')}>
                  Sign Up
                </Button>
                <Button onClick={() => setLocation('/dashboard')}>
                  Log In
                </Button>
              </div>
            )}
            
            {/* Mobile menu */}
            <div className="md:hidden ml-4">
              <Sheet open={isOpen} onOpenChange={setIsOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col space-y-4 mt-8">
                    <Link href="/project-search" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                      Projects
                    </Link>
                    <Link href="/contractor-profile" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                      Contractors
                    </Link>
                    {isAuthenticated && (
                      <Link href="/dashboard" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                        Dashboard
                      </Link>
                    )}
                    {!isAuthenticated && (
                      <>
                        <Link href="/dashboard" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                          Log In
                        </Link>
                        <Link href="/contractor-profile" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                          Sign Up
                        </Link>
                      </>
                    )}
                    {isAuthenticated && (
                      <Button variant="destructive" onClick={() => {
                        handleLogout();
                        setIsOpen(false);
                      }}>
                        Log Out
                      </Button>
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
