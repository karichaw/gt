import React, { ReactNode } from 'react';
import Header from './Header';
import Footer from './Footer';
import { useLocation } from 'wouter';

interface LayoutProps {
  children: ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [location] = useLocation();
  
  // Check if on dashboard to apply different layout
  const isDashboard = location === '/dashboard';

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {children}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Layout;
