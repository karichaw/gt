import React, { ReactNode } from 'react';

interface ActivityCardProps {
  icon: ReactNode;
  iconColor: string;
  message: React.ReactNode;
  time: string;
}

const ActivityCard: React.FC<ActivityCardProps> = ({ icon, iconColor, message, time }) => {
  return (
    <div className="py-3 flex">
      <div className="flex-shrink-0 mr-3">
        <div className={`h-8 w-8 ${iconColor} rounded-full flex items-center justify-center`}>
          {icon}
        </div>
      </div>
      <div>
        <p className="text-sm">{message}</p>
        <p className="text-xs text-gray-500">{time}</p>
      </div>
    </div>
  );
};

export default ActivityCard;
