import React from 'react';
import { Badge } from '@/components/ui/badge';

interface MatchCardProps {
  project: {
    id: number;
    title: string;
    location: string;
    budget: string;
    skills: string[];
    matchPercentage: number;
  };
  onClick?: () => void;
}

const MatchCard: React.FC<MatchCardProps> = ({ project, onClick }) => {
  return (
    <div 
      className="p-4 hover:bg-gray-50 cursor-pointer transition" 
      onClick={onClick}
    >
      <div className="flex justify-between mb-1">
        <h4 className="font-medium text-gray-900">{project.title}</h4>
        <span className="text-xs text-green-600 font-medium">{project.matchPercentage}% match</span>
      </div>
      <p className="text-sm text-gray-600 mb-2">{project.location} • {project.budget}</p>
      <div className="flex gap-1">
        {project.skills.slice(0, 1).map((skill, index) => (
          <Badge key={index} variant="outline" className="bg-primary-100 text-primary-800 border-primary-200">
            {skill}
          </Badge>
        ))}
        {project.skills.length > 1 && (
          <Badge variant="outline" className="bg-primary-100 text-primary-800 border-primary-200">
            +{project.skills.length - 1} more
          </Badge>
        )}
      </div>
    </div>
  );
};

export default MatchCard;
