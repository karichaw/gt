import React from 'react';
import { Building2, FileCheck, CheckCheck } from 'lucide-react';
import StatCard from './StatCard';
import MatchCard from './MatchCard';
import ActivityCard from './ActivityCard';
import { MessageSquare } from 'lucide-react';
import { useLocation } from 'wouter';

const Sidebar = () => {
  const [_, setLocation] = useLocation();
  
  // Mock data for recommended matches
  const recommendedMatches = [
    {
      id: 1,
      title: "Small Bridge Construction",
      location: "Bangalore",
      budget: "₹12-15 Lakhs",
      skills: ["Bridge Work", "Structural Work"],
      matchPercentage: 95
    },
    {
      id: 2,
      title: "Highway Drainage System",
      location: "Mysore",
      budget: "₹8-10 Lakhs",
      skills: ["Drainage", "Excavation"],
      matchPercentage: 87
    },
    {
      id: 3,
      title: "Culvert Reconstruction",
      location: "Bangalore",
      budget: "₹5-7 Lakhs",
      skills: ["Culvert", "Concrete Work", "Drainage"],
      matchPercentage: 80
    }
  ];

  return (
    <div className="space-y-6">
      {/* Dashboard Stats */}
      <div className="bg-white shadow rounded-lg overflow-hidden mb-6">
        <div className="bg-primary-600 text-white px-4 py-3 flex items-center justify-between">
          <h3 className="font-medium">Your Dashboard</h3>
          <button className="text-sm text-white hover:text-gray-200">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36M20.49 15a9 9 0 0 1-14.85 3.36" />
            </svg>
          </button>
        </div>
        <div className="p-4">
          <StatCard 
            title="Active Projects" 
            value="3" 
            icon={<Building2 className="h-5 w-5" />} 
            color="primary" 
          />
          <StatCard 
            title="Pending Proposals" 
            value="5" 
            icon={<FileCheck className="h-5 w-5" />} 
            color="yellow" 
          />
          <StatCard 
            title="Completed Projects" 
            value="12" 
            icon={<CheckCheck className="h-5 w-5" />} 
            color="green" 
          />
        </div>
      </div>
      
      {/* Recommended Matches */}
      <div className="bg-white shadow rounded-lg overflow-hidden mb-6">
        <div className="bg-primary-600 text-white px-4 py-3">
          <h3 className="font-medium">Recommended Matches</h3>
        </div>
        <div className="divide-y">
          {recommendedMatches.map(project => (
            <MatchCard 
              key={project.id}
              project={project}
              onClick={() => setLocation(`/project/${project.id}`)}
            />
          ))}
        </div>
        <div className="p-3 bg-gray-50 text-center">
          <button 
            className="text-sm text-primary-600 hover:text-primary-700 font-medium"
            onClick={() => setLocation('/project-search')}
          >
            View All Matches
          </button>
        </div>
      </div>
      
      {/* Recent Activity */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="bg-primary-600 text-white px-4 py-3">
          <h3 className="font-medium">Recent Activity</h3>
        </div>
        <div className="p-4 divide-y">
          <ActivityCard 
            icon={<MessageSquare className="h-4 w-4" />}
            iconColor="bg-blue-100 text-primary-600"
            message={<>You received a message from <span className="font-medium">Project Owner</span></>}
            time="2 hours ago"
          />
          <ActivityCard 
            icon={<CheckCheck className="h-4 w-4" />}
            iconColor="bg-green-100 text-green-600"
            message={<>Your proposal for <span className="font-medium">Bridge Repair</span> was accepted</>}
            time="Yesterday"
          />
          <ActivityCard 
            icon={<FileCheck className="h-4 w-4" />}
            iconColor="bg-yellow-100 text-yellow-600"
            message={<>You submitted a proposal for <span className="font-medium">Road Construction</span></>}
            time="2 days ago"
          />
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
