import React, { createContext, useContext, useState, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

interface ProjectContextType {
  createProject: (projectData: any) => Promise<any>;
  updateProject: (id: number, projectData: any) => Promise<any>;
  getProjectTypes: () => ProjectType[];
  getSubCategories: (type: string) => SubCategory[];
}

interface ProjectType {
  id: string;
  name: string;
}

interface SubCategory {
  id: string;
  name: string;
}

const ProjectContext = createContext<ProjectContextType>({
  createProject: async () => ({}),
  updateProject: async () => ({}),
  getProjectTypes: () => [],
  getSubCategories: () => [],
});

export const ProjectProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Project type options based on the classification diagram
  const projectTypes = [
    { id: 'building', name: 'Building Projects' },
    { id: 'infrastructure', name: 'Infrastructure Projects' },
    { id: 'industrial', name: 'Industrial Projects' },
    { id: 'specialized', name: 'Specialized Projects' }
  ];
  
  // Sub-categories based on selected project type
  const subCategories = {
    building: [
      { id: 'residential', name: 'Residential Buildings' },
      { id: 'commercial', name: 'Commercial Buildings' },
      { id: 'institutional', name: 'Institutional Buildings' }
    ],
    infrastructure: [
      { id: 'roads', name: 'Roads/Highways' },
      { id: 'bridges', name: 'Bridges/Culverts' },
      { id: 'drains', name: 'Drains/Sewage Systems' }
    ],
    industrial: [
      { id: 'plant_civil', name: 'Plant Civil Works' },
      { id: 'industrial_buildings', name: 'Industrial Buildings' },
      { id: 'mechanical', name: 'Mechanical Structures' },
      { id: 'tankage', name: 'Tankage Works' },
      { id: 'piping', name: 'Piping Systems' },
      { id: 'electrical', name: 'Electrical Installations' }
    ],
    specialized: [
      { id: 'renovation', name: 'Renovation/Repairs' },
      { id: 'interior', name: 'Interior Finishing' },
      { id: 'landscaping', name: 'Landscaping' }
    ]
  };

  const createProject = async (projectData: any) => {
    try {
      const response = await apiRequest('POST', '/api/projects', projectData);
      const result = await response.json();
      
      // Invalidate projects query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      
      return result;
    } catch (error) {
      console.error('Failed to create project', error);
      throw error;
    }
  };

  const updateProject = async (id: number, projectData: any) => {
    try {
      const response = await apiRequest('PUT', `/api/projects/${id}`, projectData);
      const result = await response.json();
      
      // Invalidate specific project query and all projects query
      queryClient.invalidateQueries({ queryKey: ['/api/projects', id.toString()] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      
      return result;
    } catch (error) {
      console.error(`Failed to update project ${id}`, error);
      throw error;
    }
  };

  const getProjectTypes = () => projectTypes;

  const getSubCategories = (type: string) => {
    return subCategories[type as keyof typeof subCategories] || [];
  };

  return (
    <ProjectContext.Provider value={{
      createProject,
      updateProject,
      getProjectTypes,
      getSubCategories,
    }}>
      {children}
    </ProjectContext.Provider>
  );
};

export const useProject = () => useContext(ProjectContext);
